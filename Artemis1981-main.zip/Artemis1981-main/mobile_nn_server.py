#!/usr/bin/env python3
"""
Mobile Neural Network Server
Runs on mobile device to accept connections from Linux clients
Supports multi-port listening and batch processing
"""

import socket
import json
import argparse
import threading
import time
from merge_utils import RequestPullList, squash_merge_requests

class MobileNNServer:
    # Maximum message size (10MB)
    MAX_MESSAGE_SIZE = 10 * 1024 * 1024
    
    def __init__(self, host='0.0.0.0', port=8888):
        """
        Initialize the mobile neural network server
        
        Args:
            host: Host address to bind to (default: 0.0.0.0 for all interfaces)
            port: Port number (default: 8888)
        """
        self.host = host
        self.port = port
        self.socket = None
        self.running = False
    
    def start(self):
        """Start the mobile neural network server"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket.bind((self.host, self.port))
            self.socket.listen(5)
            self.running = True
            
            print(f"✓ Mobile Neural Network Server started on {self.host}:{self.port}")
            print("Waiting for connections from Linux clients...")
            
            while self.running:
                try:
                    client_socket, address = self.socket.accept()
                    print(f"✓ Connection from {address[0]}:{address[1]}")
                    
                    # Handle client in a new thread
                    thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address)
                    )
                    thread.daemon = True
                    thread.start()
                except Exception as e:
                    if self.running:
                        print(f"✗ Error accepting connection: {e}")
        except Exception as e:
            print(f"✗ Server error: {e}")
        finally:
            self.stop()
    
    def handle_client(self, client_socket, address):
        """
        Handle individual client connection
        
        Args:
            client_socket: Socket for the client connection
            address: Client address tuple
        """
        try:
            while True:
                # Receive message length prefix
                length_bytes = self._recv_exact(client_socket, 4)
                if not length_bytes:
                    break
                
                message_length = int.from_bytes(length_bytes, 'big')
                
                # Validate message size
                if message_length > self.MAX_MESSAGE_SIZE:
                    print(f"✗ Message too large from {address[0]}: {message_length} bytes")
                    break
                
                # Receive exact message
                data = self._recv_exact(client_socket, message_length)
                if not data:
                    break
                
                try:
                    request = json.loads(data.decode('utf-8'))
                except json.JSONDecodeError as e:
                    print(f"✗ Invalid JSON from {address[0]}: {e}")
                    continue
                
                if request.get('type') == 'inference':
                    # Simulate neural network inference
                    input_data = request.get('data', [])
                    result = self.run_inference(input_data)
                    
                    response = {
                        "status": "success",
                        "result": result
                    }
                    response_data = json.dumps(response).encode('utf-8')
                    # Send message length prefix followed by message
                    length = len(response_data)
                    client_socket.sendall(length.to_bytes(4, 'big') + response_data)
                    print(f"✓ Processed inference request from {address[0]}")
        except Exception as e:
            print(f"✗ Error handling client {address[0]}: {e}")
        finally:
            client_socket.close()
            print(f"✓ Connection closed from {address[0]}:{address[1]}")
    
    def _recv_exact(self, sock, num_bytes):
        """
        Receive exact number of bytes from socket
        
        Args:
            sock: Socket to receive from
            num_bytes: Number of bytes to receive
        
        Returns:
            Received bytes or None if connection closed
        """
        data = b''
        while len(data) < num_bytes:
            chunk = sock.recv(num_bytes - len(data))
            if not chunk:
                return None
            data += chunk
        return data
    
    def run_inference(self, input_data):
        """
        Run neural network inference (mock implementation)
        
        Args:
            input_data: Input data for the neural network
        
        Returns:
            Inference result
        """
        # This is a mock implementation
        # In a real scenario, this would invoke an actual neural network model
        result = {
            "prediction": "sample_output",
            "confidence": 0.95,
            "input_shape": len(input_data) if isinstance(input_data, list) else 0
        }
        return result
    
    def stop(self):
        """Stop the server"""
        self.running = False
        if self.socket:
            self.socket.close()
            print("✓ Server stopped")


class MultiPortMobileNNServer:
    """
    Enhanced Mobile Neural Network Server with multi-port support
    Supports 6 open ports for parallel inference pipelines (including hydroanalysis)
    Includes request batching and WIP squash ordering
    """
    # Maximum message size (10MB)
    MAX_MESSAGE_SIZE = 10 * 1024 * 1024
    
    def __init__(self, host='0.0.0.0', ports=None, batch_size=10, batch_timeout=2.0):
        """
        Initialize the multi-port mobile neural network server
        
        Args:
            host: Host address to bind to (default: 0.0.0.0 for all interfaces)
            ports: List of port numbers (default: [8888, 8889, 8890, 8891, 8892, 5841])
            batch_size: Maximum requests per batch (default: 10)
            batch_timeout: Batch timeout in seconds (default: 2.0)
        """
        self.host = host
        self.ports = ports or [8888, 8889, 8890, 8891, 8892, 5841]
        self.sockets = {}
        self.running = False
        self.pull_list = RequestPullList(batch_size=batch_size, batch_timeout=batch_timeout)
        self.batch_processor_thread = None
    
    def start(self):
        """Start the multi-port mobile neural network server"""
        try:
            # Create and bind sockets for each port
            for port in self.ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((self.host, port))
                sock.listen(5)
                self.sockets[port] = sock
            
            self.running = True
            
            print(f"✓ Multi-Port Mobile Neural Network Server started")
            print(f"✓ Listening on {self.host} ports: {', '.join(map(str, self.ports))}")
            print(f"✓ Batch processing enabled: size={self.pull_list.batch_size}, timeout={self.pull_list.batch_timeout}s")
            print("Waiting for connections from Linux clients...")
            
            # Start batch processor thread
            self.batch_processor_thread = threading.Thread(target=self._batch_processor)
            self.batch_processor_thread.daemon = True
            self.batch_processor_thread.start()
            
            # Start listener threads for each port
            threads = []
            for port, sock in self.sockets.items():
                thread = threading.Thread(target=self._listen_on_port, args=(port, sock))
                thread.daemon = True
                thread.start()
                threads.append(thread)
            
            # Wait for all listener threads
            for thread in threads:
                thread.join()
                
        except Exception as e:
            print(f"✗ Server error: {e}")
        finally:
            self.stop()
    
    def _listen_on_port(self, port, sock):
        """
        Listen for connections on a specific port
        
        Args:
            port: Port number
            sock: Socket for this port
        """
        while self.running:
            try:
                client_socket, address = sock.accept()
                print(f"✓ Connection from {address[0]}:{address[1]} on port {port}")
                
                # Handle client in a new thread
                thread = threading.Thread(
                    target=self.handle_client,
                    args=(client_socket, address, port)
                )
                thread.daemon = True
                thread.start()
            except Exception as e:
                if self.running:
                    print(f"✗ Error accepting connection on port {port}: {e}")
    
    def _batch_processor(self):
        """
        Background thread that processes batched requests
        NOTE: Currently not used as requests are processed immediately
        for backward compatibility. This thread is reserved for future
        batch processing optimizations.
        """
        while self.running:
            try:
                if self.pull_list.should_process_batch():
                    # Pull batch with squash ordering
                    batch = self.pull_list.pull_batch()
                    if batch:
                        print(f"✓ Batched {len(batch)} requests (processed inline for compatibility)")
                        # In a real implementation, this would process the batch
                        # Currently requests are processed immediately in handle_client
                        pass
                
                # Sleep briefly to avoid busy waiting
                time.sleep(0.1)
            except Exception as e:
                print(f"✗ Batch processor error: {e}")
    
    def handle_client(self, client_socket, address, port):
        """
        Handle individual client connection
        
        Args:
            client_socket: Socket for the client connection
            address: Client address tuple
            port: Port number this connection came in on
        """
        try:
            while True:
                # Receive message length prefix
                length_bytes = self._recv_exact(client_socket, 4)
                if not length_bytes:
                    break
                
                message_length = int.from_bytes(length_bytes, 'big')
                
                # Validate message size
                if message_length > self.MAX_MESSAGE_SIZE:
                    print(f"✗ Message too large from {address[0]}: {message_length} bytes")
                    break
                
                # Receive exact message
                data = self._recv_exact(client_socket, message_length)
                if not data:
                    break
                
                try:
                    request = json.loads(data.decode('utf-8'))
                except json.JSONDecodeError as e:
                    print(f"✗ Invalid JSON from {address[0]}: {e}")
                    continue
                
                if request.get('type') == 'inference':
                    # Priority is based on port position in the ports list
                    # Later ports in the list get higher priority values
                    # e.g., for [8888, 8889, 8890, 8891, 8892, 5841]:
                    #   port 8888 -> priority 0
                    #   port 5841 -> priority 5 (highest)
                    priority = self.ports.index(port) if port in self.ports else 0
                    
                    # Process immediately for backward compatibility
                    # Future enhancement: Add requests to pull_list for true batch processing
                    input_data = request.get('data', [])
                    result = self.run_inference(input_data)
                    
                    response = {
                        "status": "success",
                        "result": result,
                        "port": port
                    }
                    response_data = json.dumps(response).encode('utf-8')
                    # Send message length prefix followed by message
                    length = len(response_data)
                    client_socket.sendall(length.to_bytes(4, 'big') + response_data)
                    print(f"✓ Processed inference request from {address[0]} on port {port}")
                elif request.get('type') == 'batch_inference':
                    # Handle batched requests
                    batched_data = request.get('data', [])
                    results = []
                    for data in batched_data:
                        result = self.run_inference(data)
                        results.append(result)
                    
                    response = {
                        "status": "success",
                        "results": results,
                        "count": len(results),
                        "port": port
                    }
                    response_data = json.dumps(response).encode('utf-8')
                    length = len(response_data)
                    client_socket.sendall(length.to_bytes(4, 'big') + response_data)
                    print(f"✓ Processed batch inference ({len(results)} items) from {address[0]} on port {port}")
        except Exception as e:
            print(f"✗ Error handling client {address[0]}: {e}")
        finally:
            client_socket.close()
            print(f"✓ Connection closed from {address[0]}:{address[1]} on port {port}")
    
    def _recv_exact(self, sock, num_bytes):
        """
        Receive exact number of bytes from socket
        
        Args:
            sock: Socket to receive from
            num_bytes: Number of bytes to receive
        
        Returns:
            Received bytes or None if connection closed
        """
        data = b''
        while len(data) < num_bytes:
            chunk = sock.recv(num_bytes - len(data))
            if not chunk:
                return None
            data += chunk
        return data
    
    def run_inference(self, input_data):
        """
        Run neural network inference (mock implementation)
        
        Args:
            input_data: Input data for the neural network
        
        Returns:
            Inference result
        """
        # This is a mock implementation
        # In a real scenario, this would invoke an actual neural network model
        result = {
            "prediction": "sample_output",
            "confidence": 0.95,
            "input_shape": len(input_data) if isinstance(input_data, list) else 0
        }
        return result
    
    def stop(self):
        """Stop the server"""
        self.running = False
        for port, sock in self.sockets.items():
            try:
                sock.close()
            except Exception:
                # Ignore errors when closing sockets
                pass
        print("✓ Multi-port server stopped")

def main():
    parser = argparse.ArgumentParser(
        description='Mobile Neural Network Server - run on mobile device'
    )
    parser.add_argument(
        '--port',
        type=int,
        default=8888,
        help='Port number for single-port mode (default: 8888)'
    )
    parser.add_argument(
        '--ports',
        type=str,
        help='Comma-separated list of ports for multi-port mode (e.g., "8888,8889,8890,8891,8892")'
    )
    parser.add_argument(
        '--host',
        default='0.0.0.0',
        help='Host address to bind to (default: 0.0.0.0)'
    )
    parser.add_argument(
        '--multi-port',
        action='store_true',
        help='Enable multi-port mode with 6 default ports (8888, 8889, 8890, 8891, 8892, 5841 for hydroanalysis)'
    )
    parser.add_argument(
        '--batch-size',
        type=int,
        default=10,
        help='Batch size for multi-port mode (default: 10)'
    )
    parser.add_argument(
        '--batch-timeout',
        type=float,
        default=2.0,
        help='Batch timeout in seconds for multi-port mode (default: 2.0)'
    )
    
    args = parser.parse_args()
    
    # Determine which mode to use
    if args.multi_port or args.ports:
        # Multi-port mode
        ports = None
        if args.ports:
            ports = [int(p.strip()) for p in args.ports.split(',')]
        
        server = MultiPortMobileNNServer(
            host=args.host,
            ports=ports,
            batch_size=args.batch_size,
            batch_timeout=args.batch_timeout
        )
    else:
        # Single-port mode (backward compatible)
        server = MobileNNServer(host=args.host, port=args.port)
    
    try:
        server.start()
    except KeyboardInterrupt:
        print("\n\nShutting down server...")
        server.stop()

if __name__ == "__main__":
    main()
