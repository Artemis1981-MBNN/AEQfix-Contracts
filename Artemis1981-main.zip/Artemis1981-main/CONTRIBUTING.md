# Contributing to Artemis1981

Thank you for your interest in contributing to Artemis1981! This document provides guidelines and instructions for contributing to the project.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Coding Standards](#coding-standards)
- [Testing Guidelines](#testing-guidelines)
- [Submitting Changes](#submitting-changes)
- [Priority Areas](#priority-areas)

## Code of Conduct

This project adheres to a code of conduct that all contributors are expected to follow:

- Be respectful and inclusive
- Focus on constructive feedback
- Accept differing viewpoints
- Prioritize the project's best interests
- Help create a welcoming environment

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Git
- Basic understanding of socket programming (for core features)
- Familiarity with neural networks (for ML integration)

### Setting Up Your Development Environment

1. **Fork and clone the repository**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/Artemis1981.git
   cd Artemis1981
   ```

2. **Make scripts executable**:
   ```bash
   chmod +x *.py *.sh
   ```

3. **Verify setup**:
   ```bash
   # Run tests
   python3 test_merge_utils.py
   
   # Run examples
   python3 example_merge.py
   python3 merge_utils.py
   ```

4. **Test server-client locally**:
   ```bash
   # Terminal 1: Start server
   ./mobile_nn_server.py
   
   # Terminal 2: Run client
   ./mobile_nn_client.py 127.0.0.1 --test
   ```

## Development Workflow

### 1. Create a Feature Branch

```bash
git checkout -b feature/your-feature-name
```

Use descriptive branch names:
- `feature/add-tensorflow-support`
- `bugfix/fix-connection-timeout`
- `docs/improve-readme`
- `security/add-tls-encryption`

### 2. Make Your Changes

- Keep changes focused and minimal
- Write clean, readable code
- Add comments for complex logic
- Update documentation as needed

### 3. Test Your Changes

```bash
# Run existing tests
python3 test_merge_utils.py

# Test your specific changes
# Add new tests if implementing new features
```

### 4. Commit Your Changes

Use clear, descriptive commit messages:

```bash
git add .
git commit -m "Add TensorFlow Lite model support

- Implement model loading from .tflite files
- Add model inference in run_inference method
- Update config.json with model_path parameter
- Add tests for model loading"
```

Good commit message format:
- First line: Brief summary (50 chars or less)
- Blank line
- Detailed description (wrap at 72 chars)
- List key changes with bullet points

### 5. Push and Create Pull Request

```bash
git push origin feature/your-feature-name
```

Then create a Pull Request on GitHub with:
- Clear title describing the change
- Detailed description of what and why
- Reference to related issues (if any)
- Screenshots/examples if applicable

## Coding Standards

### Python Style Guide

Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/) with these specifics:

**Indentation**: 4 spaces (no tabs)
```python
def example_function():
    if condition:
        do_something()
```

**Line Length**: Max 100 characters (prefer 80)

**Imports**: Organize in three groups
```python
# Standard library
import os
import sys

# Third-party (when we add them)
import tensorflow as tf

# Local modules
from merge_utils import merge_configs
```

**Naming Conventions**:
- Classes: `PascalCase` (e.g., `MobileNNServer`)
- Functions/Methods: `snake_case` (e.g., `send_inference_request`)
- Constants: `UPPER_SNAKE_CASE` (e.g., `MAX_MESSAGE_SIZE`)
- Private members: prefix with `_` (e.g., `_recv_exact`)

### Documentation

**Docstrings**: Use for all public functions and classes
```python
def merge_inference_results(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge multiple inference results into a single aggregated result
    
    Args:
        results: List of inference result dictionaries
    
    Returns:
        Merged result dictionary with aggregated data
    
    Example:
        >>> results = [{"status": "success", ...}, ...]
        >>> merged = merge_inference_results(results)
    """
```

**Comments**: Use sparingly, focus on why, not what
```python
# Good: Explain reasoning
# Use big-endian to ensure cross-platform compatibility
message_length = int.from_bytes(length_bytes, 'big')

# Bad: Obvious comment
# Convert bytes to int
message_length = int.from_bytes(length_bytes, 'big')
```

### Error Handling

**Use specific exceptions**:
```python
# Good
try:
    data = json.loads(json_string)
except json.JSONDecodeError as e:
    print(f"Invalid JSON: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")

# Avoid bare except
try:
    data = json.loads(json_string)
except:  # Too broad!
    pass
```

**Provide helpful error messages**:
```python
# Good
if message_length > self.MAX_MESSAGE_SIZE:
    print(f"Message too large: {message_length} bytes (max: {self.MAX_MESSAGE_SIZE})")

# Bad
if message_length > self.MAX_MESSAGE_SIZE:
    print("Error")
```

## Testing Guidelines

### Writing Tests

Tests should be:
- **Independent**: Each test should run standalone
- **Repeatable**: Same input = same output
- **Clear**: Easy to understand what's being tested

**Test Structure**:
```python
def test_feature_name():
    """Test description: what and why"""
    # Arrange: Set up test data
    input_data = [...]
    expected_output = {...}
    
    # Act: Execute the function
    result = function_under_test(input_data)
    
    # Assert: Verify the result
    assert result == expected_output, "Failure message"
    print("✓ Test passed")
```

### Test Coverage

When adding new features:
1. Add tests for the happy path
2. Add tests for edge cases (empty input, None, etc.)
3. Add tests for error conditions
4. Update existing tests if behavior changes

### Running Tests

```bash
# Run all tests
python3 test_merge_utils.py

# Run with verbose output
python3 -v test_merge_utils.py
```

## Submitting Changes

### Pull Request Checklist

Before submitting:
- [ ] Code follows PEP 8 style guidelines
- [ ] All functions have docstrings
- [ ] Tests pass
- [ ] New features have tests
- [ ] Documentation is updated
- [ ] Commit messages are clear
- [ ] No debug code or print statements left in
- [ ] No commented-out code (remove it)

### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Security fix

## Testing Done
- Describe how you tested the changes
- Include test results

## Related Issues
Fixes #123 (if applicable)

## Screenshots (if applicable)
Add screenshots for UI/output changes
```

### Code Review Process

1. Maintainers will review your PR
2. Address any feedback or requested changes
3. Once approved, your PR will be merged
4. Your contribution will be acknowledged

## Priority Areas

See [PLAN.md](PLAN.md) for the full roadmap. High-priority areas for contribution:

### 🔴 High Priority
1. **Real Neural Network Integration**
   - TensorFlow Lite support
   - ONNX Runtime support
   - PyTorch Mobile support

2. **Security Features**
   - TLS/SSL encryption
   - API key authentication
   - Rate limiting

### 🟡 Medium Priority
3. **Performance Improvements**
   - Async I/O implementation
   - Connection pooling
   - Request queuing

4. **Enhanced Testing**
   - Integration tests
   - Load testing
   - Security testing

### 🟢 Lower Priority (but still valuable!)
5. **Documentation**
   - More examples
   - Tutorial videos
   - API reference

6. **Platform Support**
   - Windows service
   - macOS launchd
   - Docker containerization

## Questions or Need Help?

- **Documentation**: Check [README.md](README.md) and [PLAN.md](PLAN.md)
- **Issues**: Search existing issues or create a new one
- **Discussions**: Use GitHub Discussions for questions

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0, the same license as the project.

---

Thank you for contributing to Artemis1981! 🚀
