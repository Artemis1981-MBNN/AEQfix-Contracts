#!/usr/bin/env python3
"""
Test suite for merge_utils module
"""

import time
from merge_utils import (
    merge_inference_results, 
    merge_configs, 
    RequestPullList, 
    squash_merge_requests
)


def test_merge_inference_results():
    """Test merging multiple inference results"""
    print("Testing merge_inference_results...")
    
    # Test with valid results
    results = [
        {"status": "success", "result": {"prediction": "cat", "confidence": 0.95, "input_shape": 5}},
        {"status": "success", "result": {"prediction": "dog", "confidence": 0.89, "input_shape": 5}},
        {"status": "success", "result": {"prediction": "cat", "confidence": 0.92, "input_shape": 5}}
    ]
    
    merged = merge_inference_results(results)
    assert merged["status"] == "success", "Status should be success"
    assert merged["result"]["count"] == 3, "Should have 3 results"
    assert len(merged["result"]["predictions"]) == 3, "Should have 3 predictions"
    assert 0.9 <= merged["result"]["average_confidence"] <= 0.95, "Average confidence should be in range"
    print("✓ Valid results test passed")
    
    # Test with empty results
    empty_merged = merge_inference_results([])
    assert empty_merged["status"] == "error", "Empty results should return error"
    print("✓ Empty results test passed")
    
    # Test with mixed success/error results
    mixed_results = [
        {"status": "success", "result": {"prediction": "cat", "confidence": 0.95}},
        {"status": "error", "message": "Failed"},
        {"status": "success", "result": {"prediction": "dog", "confidence": 0.85}}
    ]
    
    mixed_merged = merge_inference_results(mixed_results)
    assert mixed_merged["result"]["count"] == 3, "Should count all results"
    assert len(mixed_merged["result"]["predictions"]) == 2, "Should have 2 successful predictions"
    print("✓ Mixed results test passed")
    
    # Test with all error results
    error_results = [
        {"status": "error", "message": "Failed 1"},
        {"status": "error", "message": "Failed 2"}
    ]
    error_merged = merge_inference_results(error_results)
    assert error_merged["status"] == "success", "Should still return success status"
    assert error_merged["result"]["count"] == 2, "Should count error results"
    assert len(error_merged["result"]["predictions"]) == 0, "Should have no predictions"
    assert error_merged["result"]["average_confidence"] == 0.0, "Average confidence should be 0"
    print("✓ All error results test passed")


def test_merge_configs():
    """Test merging configuration dictionaries"""
    print("\nTesting merge_configs...")
    
    # Test basic merge
    config1 = {"server": {"host": "0.0.0.0"}}
    config2 = {"server": {"port": 8888}}
    
    merged = merge_configs([config1, config2])
    assert "server" in merged, "Should have server key"
    assert merged["server"]["host"] == "0.0.0.0", "Should have host"
    assert merged["server"]["port"] == 8888, "Should have port"
    print("✓ Basic merge test passed")
    
    # Test with multiple configs
    config3 = {"client": {"timeout": 10}}
    config4 = {"neural_network": {"model_type": "mobile"}}
    
    multi_merged = merge_configs([config1, config2, config3, config4])
    assert "server" in multi_merged, "Should have server"
    assert "client" in multi_merged, "Should have client"
    assert "neural_network" in multi_merged, "Should have neural_network"
    print("✓ Multiple configs test passed")
    
    # Test with overlapping keys (later values should win)
    config5 = {"server": {"port": 9999}}
    override_merged = merge_configs([config2, config5])
    assert override_merged["server"]["port"] == 9999, "Later config should override"
    print("✓ Override test passed")
    
    # Test with empty list
    empty_merged = merge_configs([])
    assert empty_merged == {}, "Empty list should return empty dict"
    print("✓ Empty list test passed")
    
    # Test deep nested merge
    deep1 = {"a": {"b": {"c": 1, "d": 2}}}
    deep2 = {"a": {"b": {"d": 3, "e": 4}}}
    deep_merged = merge_configs([deep1, deep2])
    assert deep_merged["a"]["b"]["c"] == 1, "Should preserve c from first config"
    assert deep_merged["a"]["b"]["d"] == 3, "Should override d with second config"
    assert deep_merged["a"]["b"]["e"] == 4, "Should add e from second config"
    print("✓ Deep nested merge test passed")


def test_request_pull_list():
    """Test RequestPullList for batch processing"""
    print("\nTesting RequestPullList...")
    
    # Test basic functionality
    pull_list = RequestPullList(batch_size=3, batch_timeout=1.0)
    assert pull_list.size() == 0, "Should start empty"
    print("✓ Initialization test passed")
    
    # Test adding requests
    pull_list.add_request({"type": "inference", "data": [1, 2, 3]}, priority=1)
    pull_list.add_request({"type": "inference", "data": [4, 5, 6]}, priority=5)
    pull_list.add_request({"type": "inference", "data": [7, 8, 9]}, priority=3)
    assert pull_list.size() == 3, "Should have 3 requests"
    print("✓ Add requests test passed")
    
    # Test should_process_batch with size trigger
    assert pull_list.should_process_batch() == True, "Should process when batch size reached"
    print("✓ Batch size trigger test passed")
    
    # Test pulling batch with priority ordering
    batch = pull_list.pull_batch()
    assert len(batch) == 3, "Should pull 3 requests"
    # Check priority ordering: priority 5, then 3, then 1
    assert batch[0]["data"] == [4, 5, 6], "First should be highest priority (5)"
    assert batch[1]["data"] == [7, 8, 9], "Second should be medium priority (3)"
    assert batch[2]["data"] == [1, 2, 3], "Third should be lowest priority (1)"
    assert pull_list.size() == 0, "Queue should be empty after pull"
    print("✓ Pull batch with priority ordering test passed")
    
    # Test timeout trigger
    pull_list_timeout = RequestPullList(batch_size=10, batch_timeout=0.5)
    pull_list_timeout.add_request({"type": "inference", "data": [1]}, priority=0)
    assert pull_list_timeout.should_process_batch() == False, "Should not process immediately"
    time.sleep(0.6)
    assert pull_list_timeout.should_process_batch() == True, "Should process after timeout"
    print("✓ Batch timeout trigger test passed")


def test_squash_merge_requests():
    """Test squashing multiple requests into batch"""
    print("\nTesting squash_merge_requests...")
    
    # Test with valid requests
    requests = [
        {"type": "inference", "data": [1, 2, 3]},
        {"type": "inference", "data": [4, 5, 6]},
        {"type": "inference", "data": [7, 8, 9]}
    ]
    
    squashed = squash_merge_requests(requests)
    assert squashed["type"] == "batch_inference", "Should be batch_inference type"
    assert squashed["count"] == 3, "Should have count of 3"
    assert len(squashed["data"]) == 3, "Should have 3 data items"
    assert squashed["data"][0] == [1, 2, 3], "First data should match"
    print("✓ Squash valid requests test passed")
    
    # Test with empty list
    empty_squashed = squash_merge_requests([])
    assert empty_squashed["type"] == "batch_inference", "Should be batch_inference type"
    assert empty_squashed["count"] == 0, "Should have count of 0"
    assert len(empty_squashed["data"]) == 0, "Should have empty data"
    print("✓ Squash empty list test passed")


def run_all_tests():
    """Run all tests"""
    print("=" * 50)
    print("Running Merge Utils Tests")
    print("=" * 50)
    
    try:
        test_merge_inference_results()
        test_merge_configs()
        test_request_pull_list()
        test_squash_merge_requests()
        print("\n" + "=" * 50)
        print("✓ All tests passed!")
        print("=" * 50)
        return True
    except AssertionError as e:
        print(f"\n✗ Test failed: {e}")
        return False
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        return False


if __name__ == "__main__":
    import sys
    success = run_all_tests()
    sys.exit(0 if success else 1)
