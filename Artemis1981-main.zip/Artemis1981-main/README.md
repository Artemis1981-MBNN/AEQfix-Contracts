# Artemis1981

Mobile Neural Network Connection from Linux to Phone

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/)

## Overview

This project provides a simple client-server solution to connect a mobile neural network from Linux to a phone via IP address. It enables running neural network inference on a mobile device and accessing it from a Linux system over the network.

📋 **[Project Plan & Roadmap](PLAN.md)** | 🤝 **[Contributing Guide](CONTRIBUTING.md)** | 📦 **[Installation Guide](INSTALL.md)**

## Features

- Connect from Linux to mobile neural network server via IP
- **Multi-port server support**: Listen on 6 ports simultaneously: 8888, 8889, 8890, 8891, 8892, and 5841
- **Hydroanalysis integration**: Dedicated port 5841 for hydroanalysis workflows
- Send inference requests over the network
- **Request batching and prioritization**: WIP squash ordering for efficient batch processing
- **Pull list functionality**: Queue and merge requests from multiple clients
- Simple JSON-based protocol for communication
- Configurable connection settings
- Merge utilities for combining inference results and configurations

## Requirements

- Python 3.8 or higher
- Network connectivity between Linux and mobile device
- Both devices on the same network (or proper port forwarding configured)

## Installation

For detailed installation instructions, see **[INSTALL.md](INSTALL.md)**.

### Quick Install (Recommended)

Install the package using pip:

```bash
# Install from source
git clone https://github.com/Jury1981/Artemis1981.git
cd Artemis1981
pip install .

# Or install in development mode
pip install -e .
```

After installation, you can use the following commands from anywhere:
- `mobile-nn-server` - Start the neural network server
- `mobile-nn-client` - Connect to a mobile neural network
- `merge-utils` - Run merge utilities examples

### Manual Setup (Alternative)

If you prefer to run the scripts directly without installation:

#### On the Mobile Device

1. Ensure Python 3 is installed on your mobile device (e.g., using Termux on Android)
2. Copy `mobile_nn_server.py` to your mobile device
3. Make the script executable:
   ```bash
   chmod +x mobile_nn_server.py
   ```
4. Find your phone's IP address:
   - On Android: Settings → About phone → Status → IP address
   - Or use: `ip addr show` in terminal

#### On Linux

1. Clone this repository
2. Make the client script executable:
   ```bash
   chmod +x mobile_nn_client.py
   ```

## Usage

### Starting the Server

The server can run on any device with Python 3 installed - mobile devices (e.g., Android with Termux), Raspberry Pi, or traditional Linux servers.

The server now supports two modes:
- **Single-port mode** (default): Traditional single port listening (backward compatible)
- **Multi-port mode**: Listen on 6 ports simultaneously with batch processing
  - Ports 8888, 8889, 8890, 8891, 8892: Standard inference pipelines
  - Port 5841: Dedicated for hydroanalysis integration

#### Using Installed Command (After pip install)

```bash
# Default settings (single-port mode, listens on all interfaces, port 8888)
mobile-nn-server

# Custom port (single-port mode)
mobile-nn-server --port 9999

# Specific host
mobile-nn-server --host 192.168.1.100 --port 8888

# Multi-port mode with 6 default ports (8888, 8889, 8890, 8891, 8892, and 5841 for hydroanalysis)
mobile-nn-server --multi-port

# Multi-port mode with custom ports
mobile-nn-server --ports "8888,8889,8890,8891,8892,5841"

# Multi-port mode with custom batch settings
mobile-nn-server --multi-port --batch-size 20 --batch-timeout 3.0
```

#### Manual Start (Without Installation)

```bash
# Default settings (single-port mode, listens on all interfaces, port 8888)
./mobile_nn_server.py

# Custom port (single-port mode)
./mobile_nn_server.py --port 9999

# Specific host
./mobile_nn_server.py --host 192.168.1.100 --port 8888

# Multi-port mode with 6 default ports (8888, 8889, 8890, 8891, 8892, and 5841 for hydroanalysis)
./mobile_nn_server.py --multi-port

# Multi-port mode with custom ports
./mobile_nn_server.py --ports "8888,8889,8890,8891,8892,5841"
```

#### Running as a System Service (Linux/systemd only)

For Linux systems with systemd support, you can install the server as a background service that starts automatically on boot. **Note:** This is not available on Android/mobile devices - use manual start instead.

```bash
# Install the service (requires root privileges)
sudo ./install-service.sh

# Start the service
sudo systemctl start mobile-nn-server

# Check service status
sudo systemctl status mobile-nn-server

# View service logs
sudo journalctl -u mobile-nn-server -f

# Stop the service
sudo systemctl stop mobile-nn-server

# Restart the service
sudo systemctl restart mobile-nn-server

# Uninstall the service
sudo ./uninstall-service.sh
```

The service will automatically start on system boot and restart on failure.

**Security Note:** The systemd service runs on all network interfaces (0.0.0.0:8888) without authentication. For production deployments:
- Configure firewall rules to restrict access to trusted networks
- Consider using a reverse proxy with authentication (e.g., nginx with basic auth)
- Use VPN or SSH tunneling for remote access
- Monitor service logs regularly: `sudo journalctl -u mobile-nn-server -f`

### Connecting from Linux

#### Using Installed Command (After pip install)

```bash
# Basic connection test
mobile-nn-client <PHONE_IP_ADDRESS>

# Example with phone IP 192.168.1.100
mobile-nn-client 192.168.1.100

# Custom port
mobile-nn-client 192.168.1.100 --port 9999

# Run test inference
mobile-nn-client 192.168.1.100 --test
```

#### Manual Mode (Without Installation)

```bash
# Basic connection test
./mobile_nn_client.py <PHONE_IP_ADDRESS>

# Example with phone IP 192.168.1.100
./mobile_nn_client.py 192.168.1.100

# Custom port
./mobile_nn_client.py 192.168.1.100 --port 9999

# Run test inference
./mobile_nn_client.py 192.168.1.100 --test
```

## Configuration

Edit `config.json` to customize default settings:

```json
{
  "server": {
    "host": "0.0.0.0",
    "port": 8888
  },
  "client": {
    "default_phone_ip": "192.168.1.100",
    "port": 8888,
    "timeout": 10
  }
}
```

## Example Output

### Server (Mobile):
```
✓ Mobile Neural Network Server started on 0.0.0.0:8888
Waiting for connections from Linux clients...
✓ Connection from 192.168.1.50:45678
✓ Processed inference request from 192.168.1.50
```

### Client (Linux):
```
✓ Successfully connected to mobile neural network at 192.168.1.100:8888
Sending test inference request...
✓ Inference result: {'status': 'success', 'result': {...}}
✓ Disconnected from mobile neural network
```

## Merge Utilities

The project includes `merge_utils.py` for combining multiple inference results, merging configurations, and managing request batching with priority queuing.

### Running Merge Utilities

#### Using Installed Command (After pip install)

```bash
# Run merge utilities demo (includes pull list and batch processing examples)
merge-utils
```

#### Manual Mode (Without Installation)

```bash
# Run merge utilities demo (includes pull list and batch processing examples)
./merge_utils.py
```

### Usage in Python

```python
from merge_utils import (
    merge_inference_results, 
    merge_configs,
    RequestPullList,
    squash_merge_requests
)

# Merge multiple inference results
results = [
    {"status": "success", "result": {"prediction": "cat", "confidence": 0.95}},
    {"status": "success", "result": {"prediction": "dog", "confidence": 0.89}}
]
merged = merge_inference_results(results)
# Returns a dictionary with aggregated predictions, average confidence, and count

# Merge configuration dictionaries
configs = [{"server": {"host": "0.0.0.0"}}, {"server": {"ports": [8888, 8889]}}]
merged_config = merge_configs(configs)

# Use pull list for batch processing with priority ordering
pull_list = RequestPullList(batch_size=10, batch_timeout=2.0)
pull_list.add_request({"type": "inference", "data": [1, 2, 3]}, priority=5)
pull_list.add_request({"type": "inference", "data": [4, 5, 6]}, priority=1)

# Pull batch when ready (higher priority requests first)
if pull_list.should_process_batch():
    batch = pull_list.pull_batch()
    # Process batch...

# Squash multiple requests into a single batch request
requests = [
    {"type": "inference", "data": [1, 2, 3]},
    {"type": "inference", "data": [4, 5, 6]}
]
batched = squash_merge_requests(requests)
# Returns: {"type": "batch_inference", "data": [[1,2,3], [4,5,6]], "count": 2}
```

## Random Joke Generator

The project includes a random joke generator utility that fetches jokes from the JokeAPI service.

### Installation

The joke generator requires the `requests` library. Install dependencies:

```bash
pip install -r requirements.txt
```

Or install just the required dependency:

```bash
pip install requests
```

### Usage

Run the joke generator from the command line:

```bash
# Make it executable (first time only)
chmod +x joke_generator.py

# Run the joke generator
./joke_generator.py
```

Or run it with Python:

```bash
python joke_generator.py
```

### Using in Python Code

You can also use the joke generator in your Python scripts:

```python
from joke_generator import get_random_joke, display_joke

# Fetch a random joke
joke = get_random_joke()

# Display the joke
display_joke(joke)

# Or handle the joke data manually
if joke['status'] == 'success':
    if 'joke' in joke:
        # Single joke
        print(joke['joke'])
    elif 'setup' in joke and 'delivery' in joke:
        # Two-part joke
        print(f"{joke['setup']}\n{joke['delivery']}")
else:
    print(f"Error: {joke['error']}")
```

### Features

- Fetches jokes from JokeAPI (https://v2.jokeapi.dev/)
- Handles both single and two-part jokes
- Comprehensive error handling for network issues
- Type hints for better code quality
- Filters offensive content using blacklist flags (nsfw, religious, political, racist, sexist, explicit)

## Troubleshooting

1. **Connection refused**: Make sure the server is running on the mobile device and the IP address is correct
2. **Connection timeout**: Check firewall settings and ensure both devices are on the same network
3. **Permission denied**: Ensure the scripts are executable (`chmod +x`)

## Project Documentation

- **[PLAN.md](PLAN.md)**: Comprehensive project plan, architecture, roadmap, and future enhancements
- **[CONTRIBUTING.md](CONTRIBUTING.md)**: Guidelines for contributing to the project
- **[LICENSE](LICENSE)**: Apache License 2.0

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details on:
- Setting up your development environment
- Coding standards and best practices
- Testing guidelines
- Submitting pull requests

Priority areas for contributions:
- Real neural network model integration (TensorFlow Lite, ONNX, PyTorch)
- Security features (TLS/SSL, authentication)
- Enhanced testing and documentation

## License

Apache License 2.0 - See [LICENSE](LICENSE) file for details