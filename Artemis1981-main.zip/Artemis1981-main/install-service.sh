#!/bin/bash
# Installation script for Mobile Neural Network Server systemd service

set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)"
    exit 1
fi

# Check that python3 is available
if ! command -v python3 &>/dev/null; then
    echo "Error: python3 is required but not found"
    echo "Please install Python 3.6 or higher before running this script"
    exit 1
fi
# Configuration
INSTALL_DIR="/opt/mobile-nn-server"
SERVICE_FILE="mobile-nn-server.service"
SYSTEMD_DIR="/etc/systemd/system"

echo "Installing Mobile Neural Network Server as a systemd service..."

# Validate required files exist
if [ ! -f "mobile_nn_server.py" ]; then
    echo "Error: mobile_nn_server.py not found in current directory"
    echo "Please run this script from the repository root directory"
    exit 1
fi

if [ ! -f "config.json" ]; then
    echo "Error: config.json not found in current directory"
    echo "Please run this script from the repository root directory"
    exit 1
fi

if [ ! -f "$SERVICE_FILE" ]; then
    echo "Error: $SERVICE_FILE not found in current directory"
    echo "Please run this script from the repository root directory"
    exit 1
fi

# Create service user and group if they don't exist
if ! id -u mobile-nn &>/dev/null; then
    echo "Creating service user 'mobile-nn'..."
    useradd --system --no-create-home --shell /bin/false mobile-nn
fi

# Create installation directory
echo "Creating installation directory: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
chmod 755 "$INSTALL_DIR"

# Copy server script to installation directory
echo "Copying server script..."
cp mobile_nn_server.py "$INSTALL_DIR/"

# Note: config.json is copied for reference but not currently used by the service
# The service uses command-line arguments in the systemd unit file
echo "Copying configuration file..."
cp config.json "$INSTALL_DIR/"

# Set ownership
chown -R mobile-nn:mobile-nn "$INSTALL_DIR"

# Copy systemd service file
echo "Installing systemd service file..."
cp "$SERVICE_FILE" "$SYSTEMD_DIR/"

# Reload systemd daemon
echo "Reloading systemd daemon..."
systemctl daemon-reload || true

# Enable the service
echo "Enabling service to start on boot..."
if ! systemctl enable mobile-nn-server.service; then
    echo "Error: Failed to enable service"
    exit 1
fi

echo ""
echo "✓ Installation complete!"
echo ""
echo "SECURITY NOTE: The service binds to 0.0.0.0:8888 (all network interfaces)"
echo "Make sure to configure firewall rules to restrict access to trusted networks."
echo "Consider using a reverse proxy with authentication for production deployments."
echo ""
echo "Service management commands:"
echo "  Start:   sudo systemctl start mobile-nn-server"
echo "  Stop:    sudo systemctl stop mobile-nn-server"
echo "  Restart: sudo systemctl restart mobile-nn-server"
echo "  Status:  sudo systemctl status mobile-nn-server"
echo "  Logs:    sudo journalctl -u mobile-nn-server -f"
echo ""
echo "To start the service now, run:"
echo "  sudo systemctl start mobile-nn-server"
