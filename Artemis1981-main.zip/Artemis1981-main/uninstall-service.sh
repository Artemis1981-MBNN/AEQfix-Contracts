#!/bin/bash
# Uninstallation script for Mobile Neural Network Server systemd service

set -e

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)"
    exit 1
fi

# Configuration
INSTALL_DIR="/opt/mobile-nn-server"
SERVICE_NAME="mobile-nn-server"
SYSTEMD_DIR="/etc/systemd/system"

echo "Uninstalling Mobile Neural Network Server systemd service..."

# Stop the service if running
if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo "Stopping service..."
    systemctl stop "$SERVICE_NAME" || true
fi

# Disable the service
if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo "Disabling service..."
    systemctl disable "$SERVICE_NAME" || true
fi

# Remove systemd service file
echo "Removing service file..."
rm -f "$SYSTEMD_DIR/$SERVICE_NAME.service"

# Reload systemd daemon
echo "Reloading systemd daemon..."
systemctl daemon-reload || true

# Remove installation directory
if [ -d "$INSTALL_DIR" ]; then
    echo "Removing installation directory: $INSTALL_DIR"
    rm -rf "$INSTALL_DIR"
fi

# Remove service user and group
if id -u mobile-nn &>/dev/null; then
    echo "Removing service user 'mobile-nn'..."
    userdel -r mobile-nn 2>/dev/null || true
fi

# Remove group if it still exists
if getent group mobile-nn &>/dev/null; then
    echo "Removing service group 'mobile-nn'..."
    groupdel mobile-nn 2>/dev/null || true
fi

echo ""
echo "✓ Uninstallation complete!"
echo "Mobile Neural Network Server service has been removed."
