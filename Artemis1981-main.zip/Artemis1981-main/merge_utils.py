#!/usr/bin/env python3
"""
Merge Utilities for Mobile Neural Network
Provides helper functions to merge inference results and configurations
"""

import json
import time
from typing import List, Dict, Any, Tuple
from collections import deque


def merge_inference_results(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge multiple inference results into a single aggregated result
    
    Args:
        results: List of inference result dictionaries
    
    Returns:
        Merged result dictionary with aggregated data
    """
    if not results:
        return {"status": "error", "message": "No results to merge"}
    
    # Collect all predictions and confidences
    predictions = []
    confidences = []
    
    for result in results:
        if result.get("status") == "success" and "result" in result:
            res_data = result["result"]
            if "prediction" in res_data:
                predictions.append(res_data["prediction"])
            if "confidence" in res_data:
                confidences.append(res_data["confidence"])
    
    # Calculate average confidence
    avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
    
    merged = {
        "status": "success",
        "result": {
            "predictions": predictions,
            "average_confidence": avg_confidence,
            "count": len(results)
        }
    }
    
    return merged


def merge_configs(configs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge multiple configuration dictionaries with deep merging
    
    Args:
        configs: List of configuration dictionaries
    
    Returns:
        Merged configuration dictionary
    """
    def deep_merge(base: Dict[str, Any], update: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively merge two dictionaries"""
        result = base.copy()
        for key, value in update.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = deep_merge(result[key], value)
            else:
                result[key] = value
        return result
    
    merged = {}
    for config in configs:
        merged = deep_merge(merged, config)
    return merged


class RequestPullList:
    """
    Pull list for managing and batching inference requests
    Supports WIP (Work In Progress) squash ordering
    """
    
    def __init__(self, batch_size: int = 10, batch_timeout: float = 2.0):
        """
        Initialize the pull list
        
        Args:
            batch_size: Maximum number of requests to batch together
            batch_timeout: Maximum time to wait before processing a batch (seconds)
        """
        self.batch_size = batch_size
        self.batch_timeout = batch_timeout
        self.queue = deque()
        self.last_batch_time = time.time()
    
    def add_request(self, request: Dict[str, Any], priority: int = 0) -> None:
        """
        Add a request to the pull list with priority
        
        Args:
            request: Request dictionary
            priority: Priority level (higher = more important, default: 0)
        """
        timestamp = time.time()
        self.queue.append({
            'request': request,
            'priority': priority,
            'timestamp': timestamp
        })
    
    def should_process_batch(self) -> bool:
        """
        Determine if a batch should be processed now
        
        Returns:
            True if batch should be processed, False otherwise
        """
        if not self.queue:
            return False
        
        # Process if batch size reached
        if len(self.queue) >= self.batch_size:
            return True
        
        # Process if timeout reached
        elapsed = time.time() - self.last_batch_time
        if elapsed >= self.batch_timeout and len(self.queue) > 0:
            return True
        
        return False
    
    def pull_batch(self) -> List[Dict[str, Any]]:
        """
        Pull and return a batch of requests with squash ordering
        Requests are sorted by priority (descending) then timestamp (ascending)
        
        Returns:
            List of requests in priority order
        """
        if not self.queue:
            return []
        
        # Determine batch size
        batch_count = min(len(self.queue), self.batch_size)
        
        # Extract requests from queue
        batch_items = [self.queue.popleft() for _ in range(batch_count)]
        
        # Sort by priority (descending) then timestamp (ascending)
        # This is the "squash ordering" - high priority requests first
        batch_items.sort(key=lambda x: (-x['priority'], x['timestamp']))
        
        # Update last batch time
        self.last_batch_time = time.time()
        
        # Return just the request data
        return [item['request'] for item in batch_items]
    
    def size(self) -> int:
        """Return the current queue size"""
        return len(self.queue)


def squash_merge_requests(requests: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Squash/merge multiple inference requests into a single batched request
    
    Args:
        requests: List of individual inference requests
    
    Returns:
        Single batched request containing all input data
    """
    if not requests:
        return {"type": "batch_inference", "data": [], "count": 0}
    
    # Collect all data from requests
    batched_data = []
    for req in requests:
        if req.get('type') == 'inference' and 'data' in req:
            batched_data.append(req['data'])
    
    return {
        "type": "batch_inference",
        "data": batched_data,
        "count": len(requests)
    }


def main():
    """Main function for command-line usage"""
    # Example usage
    print("Merge Utilities for Mobile Neural Network")
    print("=" * 50)
    
    # Example: Merge inference results
    sample_results = [
        {"status": "success", "result": {"prediction": "cat", "confidence": 0.95}},
        {"status": "success", "result": {"prediction": "dog", "confidence": 0.89}},
        {"status": "success", "result": {"prediction": "cat", "confidence": 0.92}}
    ]
    
    merged_result = merge_inference_results(sample_results)
    print("\nMerged Inference Results:")
    print(json.dumps(merged_result, indent=2))
    
    # Example: Merge configurations
    config1 = {"server": {"host": "0.0.0.0"}}
    config2 = {"server": {"ports": [8888, 8889]}, "client": {"timeout": 10}}
    
    merged_config = merge_configs([config1, config2])
    print("\nMerged Configuration:")
    print(json.dumps(merged_config, indent=2))
    
    # Example: Pull list with batch processing
    print("\n" + "=" * 50)
    print("Pull List and Batch Processing Demo")
    print("=" * 50)
    
    pull_list = RequestPullList(batch_size=3, batch_timeout=1.0)
    
    # Add requests with different priorities
    pull_list.add_request({"type": "inference", "data": [1, 2, 3]}, priority=1)
    pull_list.add_request({"type": "inference", "data": [4, 5, 6]}, priority=5)
    pull_list.add_request({"type": "inference", "data": [7, 8, 9]}, priority=3)
    
    print(f"\nQueue size: {pull_list.size()}")
    print(f"Should process batch: {pull_list.should_process_batch()}")
    
    # Pull batch (will be ordered by priority)
    batch = pull_list.pull_batch()
    print(f"\nPulled batch ({len(batch)} requests):")
    for i, req in enumerate(batch, 1):
        print(f"  Request {i}: {req}")
    
    # Squash merge the batch
    squashed = squash_merge_requests(batch)
    print(f"\nSquashed batch request:")
    print(json.dumps(squashed, indent=2))


if __name__ == "__main__":
    main()
