#!/usr/bin/env python3
"""
Setup script for Artemis1981 - Mobile Neural Network Connection
"""

from setuptools import setup

# Read the long description from README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read version from __init__.py if it exists, otherwise use default
VERSION = "1.0.0"

setup(
    name="artemis1981",
    version=VERSION,
    author="Artemis1981 Contributors",
    description="Mobile Neural Network Connection from Linux to Phone",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Jury1981/Artemis1981",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        # No external dependencies - uses Python standard library only
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "mobile-nn-server=mobile_nn_server:main",
            "mobile-nn-client=mobile_nn_client:main",
            "merge-utils=merge_utils:main",
        ],
    },
    # Note: install-service.sh and uninstall-service.sh are Linux/systemd-specific
    # and will only work on systems with systemd support
    scripts=[
        "install-service.sh",
        "uninstall-service.sh",
    ],
    py_modules=[
        "mobile_nn_server",
        "mobile_nn_client",
        "merge_utils",
        "example_merge",
        "test_merge_utils",
    ],
    include_package_data=True,
    zip_safe=False,
    keywords="neural-network mobile inference client-server",
    project_urls={
        "Bug Reports": "https://github.com/Jury1981/Artemis1981/issues",
        "Source": "https://github.com/Jury1981/Artemis1981",
    },
)
