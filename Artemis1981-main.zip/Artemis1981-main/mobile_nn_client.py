#!/usr/bin/env python3
"""
Mobile Neural Network Client
Connects from Linux to a mobile neural network server via IP address
"""

import socket
import json
import argparse
import sys

class MobileNNClient:
    # Default connection timeout in seconds
    DEFAULT_TIMEOUT = 10
    
    def __init__(self, phone_ip, port=8888, timeout=None):
        """
        Initialize the mobile neural network client
        
        Args:
            phone_ip: IP address of the mobile device
            port: Port number (default: 8888)
            timeout: Connection timeout in seconds (default: 10)
        """
        self.phone_ip = phone_ip
        self.port = port
        self.timeout = timeout if timeout is not None else self.DEFAULT_TIMEOUT
        self.socket = None
    
    def connect(self):
        """Establish connection to the mobile neural network server"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(self.timeout)
            self.socket.connect((self.phone_ip, self.port))
            print(f"✓ Successfully connected to mobile neural network at {self.phone_ip}:{self.port}")
            return True
        except socket.timeout:
            print(f"✗ Connection timeout: Unable to reach {self.phone_ip}:{self.port}")
            return False
        except socket.error as e:
            print(f"✗ Connection error: {e}")
            return False
    
    def send_inference_request(self, data):
        """
        Send inference request to the mobile neural network
        
        Args:
            data: Input data for neural network inference
        
        Returns:
            Response from the server or None if error
        """
        if not self.socket:
            print("✗ Not connected. Call connect() first.")
            return None
        
        try:
            request = {
                "type": "inference",
                "data": data
            }
            message = json.dumps(request).encode('utf-8')
            # Send message length prefix followed by message
            length = len(message)
            self.socket.sendall(length.to_bytes(4, 'big') + message)
            
            # Receive message length prefix
            length_bytes = self._recv_exact(4)
            if not length_bytes:
                return None
            response_length = int.from_bytes(length_bytes, 'big')
            
            # Receive exact message
            response_data = self._recv_exact(response_length)
            if not response_data:
                return None
                
            result = json.loads(response_data.decode('utf-8'))
            return result
        except Exception as e:
            print(f"✗ Error during inference request: {e}")
            return None
    
    def _recv_exact(self, num_bytes):
        """
        Receive exact number of bytes from socket
        
        Args:
            num_bytes: Number of bytes to receive
        
        Returns:
            Received bytes or None if error
        """
        data = b''
        while len(data) < num_bytes:
            chunk = self.socket.recv(num_bytes - len(data))
            if not chunk:
                return None
            data += chunk
        return data
    
    def disconnect(self):
        """Close the connection to the mobile server"""
        if self.socket:
            self.socket.close()
            self.socket = None
            print("✓ Disconnected from mobile neural network")
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.disconnect()

def main():
    parser = argparse.ArgumentParser(
        description='Connect to mobile neural network from Linux'
    )
    parser.add_argument(
        'phone_ip',
        help='IP address of the mobile device running neural network server'
    )
    parser.add_argument(
        '--port',
        type=int,
        default=8888,
        help='Port number (default: 8888)'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        default=None,
        help=f'Connection timeout in seconds (default: {MobileNNClient.DEFAULT_TIMEOUT})'
    )
    parser.add_argument(
        '--test',
        action='store_true',
        help='Run a test inference'
    )
    
    args = parser.parse_args()
    
    with MobileNNClient(args.phone_ip, args.port, args.timeout) as client:
        if client.connect():
            if args.test:
                print("\nSending test inference request...")
                test_data = [1, 2, 3, 4, 5]
                result = client.send_inference_request(test_data)
                if result:
                    print(f"✓ Inference result: {result}")
                else:
                    print("✗ Inference failed")
                    sys.exit(1)
        else:
            print("\n✗ Failed to connect to mobile neural network")
            sys.exit(1)

if __name__ == "__main__":
    main()
