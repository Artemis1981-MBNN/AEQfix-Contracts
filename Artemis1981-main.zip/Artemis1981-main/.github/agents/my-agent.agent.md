---
# Fill in the fields below to create a basic custom agent for your repository.
# The Copilot CLI can be used for local testing: https://gh.io/customagents/cli
# To make this agent available, merge this file into the default repository branch.
# For format details, see: https://gh.io/customagents/config

name:
description:
---

# My Agent

Describe what your agent does here...Configure, install and apply local changes for Jury1981/Artemis ans AMBNN as two entities and third for add on port or IP address, dns, server and vin number  
