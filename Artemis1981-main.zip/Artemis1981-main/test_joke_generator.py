#!/usr/bin/env python3
"""
Test suite for joke_generator module
"""

from unittest.mock import patch, Mock
from joke_generator import get_random_joke, display_joke
import requests


def test_get_random_joke_single_type():
    """Test handling of single-type jokes"""
    print("Testing get_random_joke with single-type joke...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock response for single joke
        mock_response = Mock()
        mock_response.json.return_value = {
            'error': False,
            'type': 'single',
            'joke': 'Why did the chicken cross the road? To get to the other side!'
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = get_random_joke()
        
        assert result['status'] == 'success', "Status should be success"
        assert 'joke' in result, "Should have joke key"
        assert result['joke'] == 'Why did the chicken cross the road? To get to the other side!', "Joke text should match"
        assert 'setup' not in result, "Should not have setup key"
        assert 'delivery' not in result, "Should not have delivery key"
    
    print("✓ Single-type joke test passed")


def test_get_random_joke_twopart_type():
    """Test handling of two-part jokes"""
    print("Testing get_random_joke with two-part joke...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock response for two-part joke
        mock_response = Mock()
        mock_response.json.return_value = {
            'error': False,
            'type': 'twopart',
            'setup': 'Why don\'t scientists trust atoms?',
            'delivery': 'Because they make up everything!'
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = get_random_joke()
        
        assert result['status'] == 'success', "Status should be success"
        assert 'setup' in result, "Should have setup key"
        assert 'delivery' in result, "Should have delivery key"
        assert result['setup'] == 'Why don\'t scientists trust atoms?', "Setup should match"
        assert result['delivery'] == 'Because they make up everything!', "Delivery should match"
        assert 'joke' not in result, "Should not have joke key"
    
    print("✓ Two-part joke test passed")


def test_get_random_joke_api_error():
    """Test handling of API errors"""
    print("Testing get_random_joke with API error...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock API error response
        mock_response = Mock()
        mock_response.json.return_value = {
            'error': True,
            'message': 'API is down for maintenance'
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = get_random_joke()
        
        assert result['status'] == 'error', "Status should be error"
        assert 'error' in result, "Should have error key"
        assert result['error'] == 'API is down for maintenance', "Error message should match"
    
    print("✓ API error test passed")


def test_get_random_joke_timeout():
    """Test handling of request timeout"""
    print("Testing get_random_joke with timeout...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock timeout error
        mock_get.side_effect = requests.exceptions.Timeout()
        
        result = get_random_joke()
        
        assert result['status'] == 'error', "Status should be error"
        assert 'error' in result, "Should have error key"
        assert 'timeout' in result['error'].lower(), "Error should mention timeout"
    
    print("✓ Timeout test passed")


def test_get_random_joke_connection_error():
    """Test handling of connection errors"""
    print("Testing get_random_joke with connection error...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock connection error
        mock_get.side_effect = requests.exceptions.ConnectionError()
        
        result = get_random_joke()
        
        assert result['status'] == 'error', "Status should be error"
        assert 'error' in result, "Should have error key"
        assert 'connection' in result['error'].lower(), "Error should mention connection"
    
    print("✓ Connection error test passed")


def test_get_random_joke_http_error():
    """Test handling of HTTP errors"""
    print("Testing get_random_joke with HTTP error...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock HTTP error
        mock_response = Mock()
        mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError('404 Not Found')
        mock_get.return_value = mock_response
        
        result = get_random_joke()
        
        assert result['status'] == 'error', "Status should be error"
        assert 'error' in result, "Should have error key"
        assert 'HTTP' in result['error'], "Error should mention HTTP"
    
    print("✓ HTTP error test passed")


def test_get_random_joke_invalid_json():
    """Test handling of invalid JSON response"""
    print("Testing get_random_joke with invalid JSON...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock invalid JSON
        mock_response = Mock()
        mock_response.json.side_effect = requests.exceptions.JSONDecodeError('Invalid', '', 0)
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = get_random_joke()
        
        assert result['status'] == 'error', "Status should be error"
        assert 'error' in result, "Should have error key"
        assert 'JSON' in result['error'], "Error should mention JSON"
    
    print("✓ Invalid JSON test passed")


def test_get_random_joke_unknown_type():
    """Test handling of unknown joke type"""
    print("Testing get_random_joke with unknown type...")
    
    with patch('joke_generator.requests.get') as mock_get:
        # Mock unknown joke type
        mock_response = Mock()
        mock_response.json.return_value = {
            'error': False,
            'type': 'unknown_type',
            'data': 'some data'
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = get_random_joke()
        
        assert result['status'] == 'error', "Status should be error"
        assert 'error' in result, "Should have error key"
        assert 'Unknown joke type' in result['error'], "Error should mention unknown type"
    
    print("✓ Unknown type test passed")


def test_display_joke_single():
    """Test display of single joke"""
    print("Testing display_joke with single joke...")
    
    with patch('builtins.print') as mock_print:
        joke_data = {
            'status': 'success',
            'joke': 'This is a test joke'
        }
        
        display_joke(joke_data)
        
        # Check that print was called with joke content
        calls = [str(call) for call in mock_print.call_args_list]
        joke_printed = any('This is a test joke' in call for call in calls)
        assert joke_printed, "Joke should be printed"
    
    print("✓ Display single joke test passed")


def test_display_joke_twopart():
    """Test display of two-part joke"""
    print("Testing display_joke with two-part joke...")
    
    with patch('builtins.print') as mock_print:
        joke_data = {
            'status': 'success',
            'setup': 'Setup line',
            'delivery': 'Punchline'
        }
        
        display_joke(joke_data)
        
        # Check that both setup and delivery were printed
        calls = [str(call) for call in mock_print.call_args_list]
        setup_printed = any('Setup line' in call for call in calls)
        delivery_printed = any('Punchline' in call for call in calls)
        assert setup_printed, "Setup should be printed"
        assert delivery_printed, "Delivery should be printed"
    
    print("✓ Display two-part joke test passed")


def test_display_joke_error():
    """Test display of error message"""
    print("Testing display_joke with error...")
    
    with patch('builtins.print') as mock_print:
        joke_data = {
            'status': 'error',
            'error': 'Test error message'
        }
        
        display_joke(joke_data)
        
        # Check that error message was printed
        calls = [str(call) for call in mock_print.call_args_list]
        error_printed = any('Test error message' in call for call in calls)
        assert error_printed, "Error message should be printed"
    
    print("✓ Display error test passed")


def run_tests():
    """Run all tests"""
    print("Running joke_generator tests...\n")
    
    tests = [
        test_get_random_joke_single_type,
        test_get_random_joke_twopart_type,
        test_get_random_joke_api_error,
        test_get_random_joke_timeout,
        test_get_random_joke_connection_error,
        test_get_random_joke_http_error,
        test_get_random_joke_invalid_json,
        test_get_random_joke_unknown_type,
        test_display_joke_single,
        test_display_joke_twopart,
        test_display_joke_error,
    ]
    
    failed_tests = []
    
    for test in tests:
        try:
            test()
        except AssertionError as e:
            print(f"✗ {test.__name__} failed: {e}")
            failed_tests.append(test.__name__)
        except Exception as e:
            print(f"✗ {test.__name__} error: {e}")
            failed_tests.append(test.__name__)
    
    print(f"\n{'='*60}")
    if not failed_tests:
        print("✓ All tests passed!")
        print(f"{'='*60}")
        return 0
    else:
        print(f"❌ {len(failed_tests)} test(s) failed:")
        for test_name in failed_tests:
            print(f"  - {test_name}")
        print(f"{'='*60}")
        return 1


if __name__ == "__main__":
    exit(run_tests())
