# Installation Guide

This guide provides detailed installation instructions for Artemis1981.

## Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Network connectivity between devices

## Installation Methods

### Method 1: Install from Source (Recommended)

1. Clone the repository:
   ```bash
   git clone https://github.com/Jury1981/Artemis1981.git
   cd Artemis1981
   ```

2. Install the package:
   ```bash
   pip install .
   ```

3. Verify installation:
   ```bash
   mobile-nn-server --help
   mobile-nn-client --help
   merge-utils
   ```

### Method 2: Development Installation

If you're planning to modify the code, use editable/development mode:

```bash
git clone https://github.com/Jury1981/Artemis1981.git
cd Artemis1981
pip install -e .
```

This allows you to make changes to the code without reinstalling.

### Method 3: Install with Development Dependencies

To install with additional development tools (pytest, etc.):

```bash
pip install -e ".[dev]"
```

## Platform-Specific Instructions

### Linux

```bash
# Standard installation
pip install .

# Or with user install (no sudo required)
pip install --user .
```

### Android (Termux)

1. Install Termux from F-Droid or Google Play
2. Update packages and install Python:
   ```bash
   pkg update && pkg upgrade
   pkg install python git
   ```
3. Clone and install:
   ```bash
   git clone https://github.com/Jury1981/Artemis1981.git
   cd Artemis1981
   pip install .
   ```

### macOS

```bash
# Ensure Python 3 and pip are installed
brew install python3

# Clone and install
git clone https://github.com/Jury1981/Artemis1981.git
cd Artemis1981
pip3 install .
```

## Verifying Installation

After installation, verify that all commands are available:

```bash
# Check server command
mobile-nn-server --help

# Check client command
mobile-nn-client --help

# Check merge utilities
merge-utils

# Check Python package
python3 -c "import mobile_nn_server; import mobile_nn_client; import merge_utils; print('All modules imported successfully!')"
```

## Installing as a System Service (Linux only)

For Linux systems with systemd, you can install the server as a system service:

```bash
# First install the package
pip install .

# Then install the systemd service (requires sudo)
sudo ./install-service.sh

# Start the service
sudo systemctl start mobile-nn-server

# Enable auto-start on boot
sudo systemctl enable mobile-nn-server
```

See README.md for more details on service management.

## Uninstalling

To uninstall the package:

```bash
pip uninstall artemis1981
```

To remove the systemd service (if installed):

```bash
sudo ./uninstall-service.sh
```

## Troubleshooting

### Command not found

If you get "command not found" errors after installation:

1. Check if pip's bin directory is in your PATH:
   ```bash
   echo $PATH | grep -o "$HOME/.local/bin"
   ```

2. If not found, add it to your shell configuration:
   ```bash
   # For bash
   echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
   source ~/.bashrc
   
   # For zsh
   echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
   source ~/.zshrc
   ```

### Permission errors

If you get permission errors during installation:

1. Use user installation:
   ```bash
   pip install --user .
   ```

2. Or use a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install .
   ```

### Import errors

If you get import errors when running the commands:

1. Ensure the package is properly installed:
   ```bash
   pip show artemis1981
   ```

2. Try reinstalling:
   ```bash
   pip uninstall artemis1981
   pip install .
   ```

## Building Distribution Packages

To build distribution packages (wheel and source):

```bash
# Install build tool
pip install build

# Build packages using modern build system
python -m build

# Packages will be in dist/ directory
ls -lh dist/
```

Note: If you need to use the legacy method with setup.py, you can still run:
```bash
python setup.py sdist bdist_wheel
```

However, the modern `python -m build` approach is recommended.

## Next Steps

After installation, see the [README.md](README.md) for usage instructions and examples.
