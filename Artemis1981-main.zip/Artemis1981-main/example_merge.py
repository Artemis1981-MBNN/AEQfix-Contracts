#!/usr/bin/env python3
"""
Integration example: Using merge utilities with client-server
This demonstrates how to use merge_utils with the mobile neural network
"""

import json
from merge_utils import merge_inference_results, merge_configs


def example_batch_inference():
    """
    Example: Simulate multiple inference requests and merge results
    This is what you would get from running multiple client requests
    """
    print("Example: Batch Inference with Result Merging")
    print("=" * 50)
    
    # Simulate results from multiple inference requests
    # (These would come from actual client.send_inference_request() calls)
    inference_results = [
        {
            "status": "success",
            "result": {
                "prediction": "sample_output",
                "confidence": 0.95,
                "input_shape": 5
            }
        },
        {
            "status": "success",
            "result": {
                "prediction": "sample_output",
                "confidence": 0.88,
                "input_shape": 3
            }
        },
        {
            "status": "success",
            "result": {
                "prediction": "sample_output",
                "confidence": 0.92,
                "input_shape": 4
            }
        }
    ]
    
    # Merge all results
    merged = merge_inference_results(inference_results)
    
    print("\nIndividual Results:")
    for i, result in enumerate(inference_results, 1):
        print(f"  Request {i}: confidence={result['result']['confidence']}")
    
    print("\nMerged Result:")
    print(json.dumps(merged, indent=2))
    
    return merged


def example_config_merge():
    """
    Example: Merge configuration from multiple sources
    Useful when combining default config with user overrides
    """
    print("\n" + "=" * 50)
    print("Example: Configuration Merging")
    print("=" * 50)
    
    # Load base config from file
    try:
        with open('config.json', 'r') as f:
            base_config = json.load(f)
        print("\nBase Configuration:")
        print(json.dumps(base_config, indent=2))
    except FileNotFoundError:
        base_config = {}
        print("\nNo config.json found, using empty base")
    
    # User overrides
    user_config = {
        "server": {
            "port": 9999  # Override port
        },
        "client": {
            "timeout": 30  # Override timeout
        }
    }
    
    print("\nUser Overrides:")
    print(json.dumps(user_config, indent=2))
    
    # Merge configs
    final_config = merge_configs([base_config, user_config])
    
    print("\nFinal Merged Configuration:")
    print(json.dumps(final_config, indent=2))
    
    return final_config


if __name__ == "__main__":
    print("Mobile Neural Network - Merge Utilities Integration Examples")
    print("=" * 60)
    print()
    
    # Run examples
    example_batch_inference()
    example_config_merge()
    
    print("\n" + "=" * 60)
    print("✓ Examples completed successfully")
    print("=" * 60)
