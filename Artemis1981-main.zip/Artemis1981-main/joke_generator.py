#!/usr/bin/env python3
"""
Random Joke Generator using JokeAPI
Fetches and displays random jokes from https://v2.jokeapi.dev/
"""

import requests
from typing import Dict, Union


def get_random_joke() -> Dict[str, Union[str, bool]]:
    """
    Fetch a random joke from JokeAPI.
    
    Returns:
        Dict containing joke data with 'status', 'joke' or 'setup'/'delivery' keys,
        and 'error' message if request fails.
    
    Example single joke:
        {'status': 'success', 'joke': 'Why did the chicken cross the road?...'}
    
    Example two-part joke:
        {'status': 'success', 'setup': 'Why did the chicken...', 'delivery': 'To get...'}
    """
    api_url = "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit"
    
    try:
        response = requests.get(api_url, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # Check if API returned an error
        if data.get('error', False):
            return {
                'status': 'error',
                'error': data.get('message', 'Unknown API error')
            }
        
        # Handle single joke type
        if data.get('type') == 'single':
            return {
                'status': 'success',
                'joke': data.get('joke', '')
            }
        
        # Handle two-part joke type
        elif data.get('type') == 'twopart':
            return {
                'status': 'success',
                'setup': data.get('setup', ''),
                'delivery': data.get('delivery', '')
            }
        
        else:
            return {
                'status': 'error',
                'error': 'Unknown joke type received from API'
            }
    
    except requests.exceptions.Timeout:
        return {
            'status': 'error',
            'error': 'Request timeout - API did not respond in time'
        }
    
    except requests.exceptions.ConnectionError:
        return {
            'status': 'error',
            'error': 'Connection error - Unable to reach API'
        }
    
    except requests.exceptions.HTTPError as e:
        return {
            'status': 'error',
            'error': f'HTTP error: {e}'
        }
    
    except requests.exceptions.JSONDecodeError:
        return {
            'status': 'error',
            'error': 'Invalid JSON response from API'
        }
    
    except requests.exceptions.RequestException as e:
        return {
            'status': 'error',
            'error': f'Request error: {e}'
        }
    
    except Exception as e:
        return {
            'status': 'error',
            'error': f'Unexpected error: {e}'
        }


def display_joke(joke_data: Dict[str, Union[str, bool]]) -> None:
    """
    Display a joke in a formatted way.
    
    Args:
        joke_data: Dictionary containing joke information from get_random_joke()
    """
    if joke_data.get('status') == 'error':
        print(f"❌ Error: {joke_data.get('error', 'Unknown error')}")
        return
    
    print("\n" + "=" * 60)
    
    if 'joke' in joke_data:
        # Single joke
        print(f"😂 {joke_data['joke']}")
    elif 'setup' in joke_data and 'delivery' in joke_data:
        # Two-part joke
        print(f"😂 {joke_data['setup']}")
        print(f"   {joke_data['delivery']}")
    else:
        print("❌ Error: Invalid joke format")
    
    print("=" * 60 + "\n")


def main() -> None:
    """Main function for command-line interaction"""
    print("🎭 Random Joke Generator")
    print("Fetching a random joke from JokeAPI...\n")
    
    joke = get_random_joke()
    display_joke(joke)


if __name__ == "__main__":
    main()
