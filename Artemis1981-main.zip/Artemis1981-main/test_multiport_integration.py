#!/usr/bin/env python3
"""
Integration test for multi-port server
Tests client connections to different ports
"""

import socket
import json
import threading
import time
import sys
from mobile_nn_server import MultiPortMobileNNServer


def test_multiport_server():
    """Test that server accepts connections on all ports"""
    print("=" * 60)
    print("Multi-Port Server Integration Test")
    print("=" * 60)
    
    # Start server in background thread
    server = MultiPortMobileNNServer(
        host='127.0.0.1',
        ports=[8888, 8889, 5841],  # Test with subset of ports
        batch_size=5,
        batch_timeout=1.0
    )
    
    server_thread = threading.Thread(target=server.start)
    server_thread.daemon = True
    server_thread.start()
    
    # Give server time to start
    time.sleep(1)
    
    print("\n✓ Server started on ports: 8888, 8889, 5841")
    
    # Test connections to each port
    test_ports = [8888, 8889, 5841]
    results = []
    
    for port in test_ports:
        try:
            print(f"\nTesting connection to port {port}...")
            
            # Create client socket
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.settimeout(5)
            client.connect(('127.0.0.1', port))
            
            # Send test inference request
            request = {"type": "inference", "data": [1, 2, 3, 4, 5]}
            request_data = json.dumps(request).encode('utf-8')
            length = len(request_data)
            client.sendall(length.to_bytes(4, 'big') + request_data)
            
            # Receive response
            length_bytes = client.recv(4)
            if length_bytes:
                response_length = int.from_bytes(length_bytes, 'big')
                response_data = b''
                while len(response_data) < response_length:
                    chunk = client.recv(response_length - len(response_data))
                    if not chunk:
                        break
                    response_data += chunk
                
                response = json.loads(response_data.decode('utf-8'))
                
                if response.get('status') == 'success':
                    print(f"  ✓ Port {port}: SUCCESS - Received response")
                    print(f"    Response port: {response.get('port')}")
                    print(f"    Result: {response.get('result', {}).get('prediction')}")
                    results.append(True)
                else:
                    print(f"  ✗ Port {port}: FAILED - Bad response")
                    results.append(False)
            else:
                print(f"  ✗ Port {port}: FAILED - No response")
                results.append(False)
            
            client.close()
            
        except Exception as e:
            print(f"  ✗ Port {port}: FAILED - {e}")
            results.append(False)
    
    # Stop server
    server.stop()
    time.sleep(0.5)
    
    # Report results
    print("\n" + "=" * 60)
    print(f"Results: {sum(results)}/{len(results)} ports tested successfully")
    
    if all(results):
        print("✓ All multi-port tests passed!")
        print("=" * 60)
        return True
    else:
        print("✗ Some multi-port tests failed")
        print("=" * 60)
        return False


def test_hydroanalysis_port():
    """Test hydroanalysis port 5841 specifically"""
    print("\n" + "=" * 60)
    print("Hydroanalysis Port 5841 Test")
    print("=" * 60)
    
    # Start server with all ports
    server = MultiPortMobileNNServer(
        host='127.0.0.1',
        ports=[8888, 8889, 8890, 8891, 8892, 5841]
    )
    
    server_thread = threading.Thread(target=server.start)
    server_thread.daemon = True
    server_thread.start()
    
    time.sleep(1)
    print("\n✓ Server started with all 6 ports")
    
    try:
        print(f"\nTesting hydroanalysis port 5841...")
        
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(5)
        client.connect(('127.0.0.1', 5841))
        
        # Send hydroanalysis-style request
        request = {"type": "inference", "data": [10, 20, 30, 40, 50]}
        request_data = json.dumps(request).encode('utf-8')
        length = len(request_data)
        client.sendall(length.to_bytes(4, 'big') + request_data)
        
        # Receive response
        length_bytes = client.recv(4)
        response_length = int.from_bytes(length_bytes, 'big')
        response_data = b''
        while len(response_data) < response_length:
            chunk = client.recv(response_length - len(response_data))
            if not chunk:
                break
            response_data += chunk
        
        response = json.loads(response_data.decode('utf-8'))
        
        if response.get('status') == 'success' and response.get('port') == 5841:
            print(f"  ✓ Hydroanalysis port 5841: SUCCESS")
            print(f"    Confirmed port in response: {response.get('port')}")
            print(f"    Result: {response.get('result')}")
            client.close()
            server.stop()
            print("\n✓ Hydroanalysis port test passed!")
            print("=" * 60)
            return True
        else:
            print(f"  ✗ Hydroanalysis port 5841: FAILED")
            client.close()
            server.stop()
            return False
            
    except Exception as e:
        print(f"  ✗ Hydroanalysis port 5841: FAILED - {e}")
        server.stop()
        return False


if __name__ == "__main__":
    print("\nRunning Multi-Port Integration Tests")
    print("=" * 60)
    
    # Run tests
    test1 = test_multiport_server()
    test2 = test_hydroanalysis_port()
    
    # Final results
    print("\n" + "=" * 60)
    print("FINAL RESULTS")
    print("=" * 60)
    
    if test1 and test2:
        print("✓ All integration tests passed!")
        sys.exit(0)
    else:
        print("✗ Some integration tests failed")
        sys.exit(1)
