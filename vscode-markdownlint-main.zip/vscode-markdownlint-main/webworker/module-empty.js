// @ts-check

"use strict";

module.exports = {};
