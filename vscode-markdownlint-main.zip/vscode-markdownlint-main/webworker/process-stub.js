// @ts-check

"use strict";

module.exports = {
	"cwd": () => "/",
	"env": {},
	"versions": {
		"node": "0.0"
	}
};
