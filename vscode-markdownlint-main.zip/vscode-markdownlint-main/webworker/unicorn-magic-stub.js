// @ts-check

"use strict";

module.exports = {
	"toPath": (path) => path
};
