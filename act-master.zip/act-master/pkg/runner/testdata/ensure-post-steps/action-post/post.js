if (process.env["INPUT_FAIL"] === "true") {
  process.exit(1);
}
